package application;



public final class Chart {

	private final String xValue;
	private final Double yValue;
	
	public Chart(String xValue, Double yValue) {
		super();
		this.xValue = xValue;
		this.yValue = yValue;
	}
	public String getXValue() {
		return xValue;
	}
	public Double getYValue() {
		return yValue;
	}
	
	
	
	
	
}
