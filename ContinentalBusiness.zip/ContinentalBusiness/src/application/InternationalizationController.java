package application;

import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

public class InternationalizationController implements Initializable{
	@FXML
	private RadioButton english;
	@FXML
	private RadioButton hindi;	
	@FXML
	private TextField result;
	private Locale locale;
	private ResourceBundle resourceBundle;
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}
	public void EnglishAction()
	{
		loadlang("en");	
	}
	public void HindiAction()
	{
		loadlang("hi");	
	}
	
	public void loadlang(String lang)
	{
		this.locale=new Locale(lang);
		
		this.resourceBundle=ResourceBundle.getBundle("application.resources.lang",locale);
		this.result.setText(this.resourceBundle.getString("result"));
	}
}
