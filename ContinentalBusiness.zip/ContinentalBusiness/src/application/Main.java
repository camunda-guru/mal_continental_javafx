package application;
	
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;


public class Main extends Application {
	
	private MenuLib menuLib;
	private ToolLib toolLib;
	private TabLib tabLib;
	private PolygonChart chart;
	private Stage stage;
	@Override
	public void start(Stage primaryStage) {
		this.stage=primaryStage;
		this.menuLib=new MenuLib();
		this.toolLib=new ToolLib();
		this.tabLib=new TabLib();
		this.chart=new PolygonChart();
		 VBox topBox = new VBox(menuLib.createMenus(),toolLib.createToolBar());
		 BorderPane borderPane = new BorderPane();
		 Line line = new Line(0,10,1900,10);
		 line.setStroke(Color.BLUE);
		 line.setStrokeWidth(6);
		 HBox hbox=new HBox(chart.getChart(),chart.getChartTable());
		 VBox tabBox = new VBox(tabLib.createTabs(),line,hbox);
	     borderPane.setCenter(tabBox);	     
	        borderPane.setTop(topBox);
		 Scene scene = new Scene(borderPane, 580, 600);
	        scene.getStylesheets().add("application/application.css");
	        stage.setScene(scene);
	        stage.setTitle("Continental App");
	        stage.show();
	}
	//initialDelay, PERIOD, TimeUnit.MILLISECONDS
	public static void main(String[] args) {
		launch(args);
		ScheduledExecutorService execService
		=	Executors.newScheduledThreadPool(5);
execService.scheduleAtFixedRate(()->{
	//launch(args);
//The repetitive task, say to update Database
System.out.println("hi there at: "+ new java.util.Date());
}, 10, 3000L, TimeUnit.MILLISECONDS);
	}
}
