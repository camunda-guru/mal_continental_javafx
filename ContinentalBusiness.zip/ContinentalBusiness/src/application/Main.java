package application;
	
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Line;


public class Main extends Application {
	
	private MenuLib menuLib;
	private ToolLib toolLib;
	private TabLib tabLib;
	private Stage stage;
	@Override
	public void start(Stage primaryStage) {
		this.stage=primaryStage;
		this.menuLib=new MenuLib();
		this.toolLib=new ToolLib();
		this.tabLib=new TabLib();
		 VBox topBox = new VBox(menuLib.createMenus(),toolLib.createToolBar());
		 BorderPane borderPane = new BorderPane();
		 Line line = new Line(0,50,1900,50);
		 VBox tabBox = new VBox(tabLib.createTabs(),line);
	     borderPane.setCenter(tabBox);
	        borderPane.setTop(topBox);
		 Scene scene = new Scene(borderPane, 580, 600);
	        scene.getStylesheets().add("application/application.css");
	        stage.setScene(scene);
	        stage.setTitle("Continental App");
	        stage.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
