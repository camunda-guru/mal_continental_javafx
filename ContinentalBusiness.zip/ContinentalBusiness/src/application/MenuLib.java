package application;

import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCombination;

public class MenuLib {
	
	public MenuBar createMenus()
	{
		MenuItem itemNew = new MenuItem("New...", new ImageView(
                new Image(getClass().getResourceAsStream("images/paper.png"))));
        itemNew.setAccelerator(KeyCombination.keyCombination("Ctrl+N"));
        itemNew.setOnAction(e -> System.out.println(e.getEventType()
                + " occurred on MenuItem New"));
        MenuItem itemSave = new MenuItem("Save");
        Menu menuFile = new Menu("File");
        menuFile.getItems().addAll(itemNew, itemSave);
        MenuItem itemCut = new MenuItem("Cut");
        MenuItem itemCopy = new MenuItem("Copy");
        MenuItem itemPaste = new MenuItem("Paste");
        Menu menuEdit = new Menu("Edit");
        menuEdit.getItems().addAll(itemCut, itemCopy, itemPaste);
        Menu menuOnline = new Menu("Online");
        Menu menuHistory = new Menu("History");
        Menu menuDashboard = new Menu("Dashboard");
        Menu menuSettings = new Menu("Settings");
        Menu menuHelp= new Menu("Help");
        MenuBar menuBar = new MenuBar();
        menuBar.getMenus().addAll(menuFile, menuEdit,menuOnline,menuHistory,menuDashboard,
        		menuSettings,menuHelp);
        return menuBar;
	}

}
