package application;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public final class Person {
  private String id;
  private String name;
  private String userName;
  private String email;
  private String address;
  private String phoneNo;
  private String webSite;
  private String company;
  
public Person(String id, String name, String userName, String email, String address, String phoneNo, String webSite,
		String company) {
	super();
	this.id = id;
	this.name = name;
	this.userName = userName;
	this.email = email;
	this.address = address;
	this.phoneNo = phoneNo;
	this.webSite = webSite;
	this.company = company;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getPhoneNo() {
	return phoneNo;
}
public void setPhoneNo(String phoneNo) {
	this.phoneNo = phoneNo;
}
public String getWebSite() {
	return webSite;
}
public void setWebSite(String webSite) {
	this.webSite = webSite;
}
public String getCompany() {
	return company;
}
public void setCompany(String company) {
	this.company = company;
}
  
  
}