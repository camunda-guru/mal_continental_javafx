package application;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class PolygonChart {

	public  ObservableList<Chart> chartList;
	
	
	public LineChart getChart()
	{
		
		CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        LineChart lineChart = new LineChart(xAxis, yAxis);
        lineChart.setData(getChartData());
        lineChart.setTitle("Speed vs Time");            
        
		return lineChart;
	}
	
	
	TableView getChartTable()
	{
		
		 TableView tableView=null;
			tableView = new TableView(chartList);
			tableView.setId("chartData");
			
			TableColumn xData = new TableColumn("X");
			//get property must be getXValue,getYValue
			xData.setCellValueFactory(new PropertyValueFactory("xValue"));
			xData.setPrefWidth(80);
     
			TableColumn yData = new TableColumn("Y");
			yData.setCellValueFactory(new PropertyValueFactory<Chart,String>("yValue"));
			yData.setPrefWidth(80);
			
			tableView .getColumns().addAll(xData,yData);
			tableView .getSelectionModel().selectedItemProperty()
			        .addListener((ObservableValue observable, Object oldValue,
			        		Object newValue) -> {
			            Chart selectedChart = (Chart) newValue;
			            System.out.println(selectedChart + " chosen in TableView");
			        });
			
			 return tableView; 
	}
	
	
	private ObservableList<XYChart.Series<String, Double>> getChartData() {
        
      
        ObservableList<XYChart.Series<String, Double>> polygonList = 
        		FXCollections.observableArrayList();
        Series<String, Double> polygon = new Series<String, Double>();
        polygon.setName("Speed(Kmph)");
        double time = 5.5;
		 chartList=FXCollections.observableArrayList(); 
		 for (int i = 10; i < 100; i+=10) {
			   chartList.add(new Chart(Integer.toString(i),time));
			 polygon.getData().add(new XYChart.Data(Integer.toString(i),time));
	            time = time + Math.random() - .5;	         
	        }
               
        polygonList.addAll(polygon);
        return polygonList;
    }
	
	
	
}
