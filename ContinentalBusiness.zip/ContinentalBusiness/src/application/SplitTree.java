package application;

import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;

public class SplitTree {

	Node createSplitTreeListDemoNode() {
        TreeItem animalTree = new TreeItem("Animal");
        animalTree.getChildren().addAll(new TreeItem("Lion"), new TreeItem("Tiger"), new TreeItem("Bear"));
        TreeItem mineralTree = new TreeItem("Mineral");
        mineralTree.getChildren().addAll(new TreeItem("Copper"), new TreeItem("Diamond"), new TreeItem("Quartz"));
        TreeItem vegetableTree = new TreeItem("Vegetable");
        vegetableTree.getChildren().addAll(new TreeItem("Arugula"), new TreeItem("Broccoli"), new TreeItem("Cabbage"));

        TreeItem root = new TreeItem("Root");
        root.getChildren().addAll(animalTree, mineralTree, vegetableTree);
        TreeView treeView = new TreeView(root);
        treeView.setMinWidth(150);
        treeView.setShowRoot(false);
        treeView.setEditable(false);
        ObservableList listViewItems = FXCollections.observableArrayList();  
        ListView listView = new ListView(listViewItems);

        SplitPane splitPane = new SplitPane();
        splitPane.getItems().addAll(treeView, listView);

        treeView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        treeView.getSelectionModel().selectedItemProperty()
                .addListener((ObservableValue observable, Object oldValue, Object newValue) -> {
                    TreeItem treeItem = (TreeItem) newValue;
                    if (newValue != null && treeItem.isLeaf()) {
                        listViewItems.clear();
                        for (int i = 1; i <= 10000; i++) {
                            listViewItems.add(treeItem.getValue() + " " + i);
                        }
                    }
                });

        return splitPane;
    }
}
