package application;

import java.io.IOException;
import java.net.URL;
import java.util.zip.GZIPInputStream;

import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingNode;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Orientation;
import javafx.scene.Node;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebView;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonString;
import javax.json.JsonValue;
import javax.swing.SwingUtilities;

public class TabLib {

	TabPane createTabs() {
        final WebView webView = new WebView();
        Tab tableTab = new Tab("TableView");
        tableTab.setContent(createTableDemoNode());
        tableTab.setClosable(false);
        Tab accordionTab = new Tab("Accordion/TitledPane");
        //accordionTab.setContent(createAccordionTitledDemoNode());
        accordionTab.setClosable(false);
        Tab splitTab = new Tab("SplitPane/TreeView/ListView");
        splitTab.setContent(new SplitTree().createSplitTreeListDemoNode());
        splitTab.setClosable(false);
        Tab listTableTab = new Tab("ListTableView");
        listTableTab.setContent(createTreeTableDemoNode());
        listTableTab.setClosable(false);
        Tab scrollTab = new Tab("ScrollPane/Miscellaneous");
        scrollTab.setContent(createScrollMiscDemoNode());
        scrollTab.setClosable(false);
        Tab htmlTab = new Tab("HTMLEditor");
        //htmlTab.setContent(createHtmlEditorDemoNode());
        htmlTab.setClosable(false);
        Tab webViewTab = new Tab("WebView");
        webViewTab.setContent(webView);
        webViewTab.setClosable(false);
        webViewTab.setOnSelectionChanged(e -> {
            //String randomWebSite = model.getRandomWebSite();
            if (webViewTab.isSelected()) {
                webView.getEngine().load("http://localhost:63342/CanvasSVG/SVG/Animation.html");
                System.out.println("WebView tab is selected, loading: "
                        );
            }
        });
        TabPane tabPane = new TabPane();
        tabPane.setPrefHeight(400);
       // tabPane.setMaxHeight(500);
        tabPane.getTabs().addAll(
                tableTab,
                accordionTab,
                splitTab,
                listTableTab,
                scrollTab,
                htmlTab,
                webViewTab
        );

        return tabPane;
    }
	

	
	
	Node createTableDemoNode() {
        TableView tableView=null;
		try {
			tableView = new TableView(getObservableList());
			//tableView.setMaxHeight(250);
			//tableView.setPrefHeight(150);
			tableView.setId("UserData");
		  
	        TableColumn id = new TableColumn("Id");
	        id.setCellValueFactory(new PropertyValueFactory("id"));
	       id.setPrefWidth(80);
	       
	        TableColumn name = new TableColumn("Name");
	        name.setCellValueFactory(new PropertyValueFactory("name"));
	        name.setPrefWidth(180);
	        TableColumn userName = new TableColumn("UserName");
	        userName.setCellValueFactory(new PropertyValueFactory("userName"));
	        userName.setPrefWidth(180);
	        TableColumn email = new TableColumn("Email");
	        email.setCellValueFactory(new PropertyValueFactory("email"));
	        email.setPrefWidth(280);
	        tableView .getColumns().addAll(id, name, userName,email);
	        tableView .getSelectionModel().selectedItemProperty()
	                .addListener((ObservableValue observable, Object oldValue, Object newValue) -> {
	                    Person selectedPerson = (Person) newValue;
	                    System.out.println(selectedPerson + " chosen in TableView");
	                });
	       
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return tableView; 
        

    }
	
	
		public ObservableList<Person> getObservableList() throws IOException {
			String url = "https://jsonplaceholder.typicode.com/users";
			URL host = new URL(url);
			JsonReader jr = Json.createReader(host.openConnection().getInputStream());	
			
			JsonArray jsonArray = (JsonArray) jr.read();
			ObservableList<Person> personList = FXCollections.observableArrayList();
			jsonArray.iterator().forEachRemaining((JsonValue e) -> {
			JsonObject obj = (JsonObject) e;
			JsonNumber id= obj.getJsonNumber("id");
			JsonString name = obj.getJsonString("name");
			JsonString username = obj.getJsonString("username");
			JsonString email = obj.getJsonString("email");
			JsonObject address = obj.getJsonObject("address");
			JsonString phone = obj.getJsonString("phone");
			JsonString website = obj.getJsonString("website");
			JsonObject company = obj.getJsonObject("company");
			//JsonNumber jsonNumber = obj.getJsonNumber("creation_date");
			Person person = new Person(id.toString(),name.getString(), username.getString(),email.getString(),
					address.toString(), phone.getString(),website.getString(),company.toString());
			personList.add(person);
			
			});
			return 	personList;
			}
		
		
	Node createScrollMiscDemoNode()
	{
		FXMLLoader fxmlLoader = new FXMLLoader();
		fxmlLoader.setLocation(
				TabLib.class.getResource("Internationalization.fxml"));
		fxmlLoader.setController(
		new InternationalizationController());
		VBox vBox=null;
		try {
			vBox = fxmlLoader.load();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return vBox;
	}
   Node createTreeTableDemoNode()
   {
	   final SwingNode sn = new SwingNode();

       SwingUtilities.invokeLater(new Runnable() {
           @Override
           public void run() {
               sn.setContent(new TableSortDemo());
           }
       });
       return sn;
   }
}
