package application;

import javafx.geometry.Orientation;
import javafx.scene.control.Button;
import javafx.scene.control.Separator;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.ToolBar;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class ToolLib {

	
	public ToolBar createToolBar()
	{
		Button newButton = new Button();
		//Image(InputStream is, double requestedWidth, double requestedHeight, 
		//boolean preserveRatio, boolean smooth)
        newButton.setGraphic(new ImageView(new Image(getClass()
        		.getResourceAsStream("images/new.png"),50,50,false, true)));
        newButton.setId("newButton");
        newButton.setTooltip(new Tooltip("New Document... Ctrl+D"));
        newButton.setOnAction(e -> System.out.println("New toolbar button clicked"));
        Button editButton = new Button();
        editButton.setGraphic(new ImageView(new Image(getClass()
        		.getResourceAsStream("images/edit.png"),50,50,false, true)));
        editButton.setId("editButton");
        Button deleteButton = new Button();
        deleteButton.setGraphic(new ImageView(new Image(getClass()
        		.getResourceAsStream("images/delete.png"),50,50,false, true)));
        deleteButton.setId("deleteButton");
        Button helpButton = new Button();
        helpButton.setGraphic(new ImageView(new Image(getClass()
        		.getResourceAsStream("images/help.png"),50,50,false, true)));
        helpButton.setId("helpButton");
        Button downloadButton = new Button();
        downloadButton.setGraphic(new ImageView(new Image(getClass()
        		.getResourceAsStream("images/download.png"),50,50,false, true)));
        downloadButton.setId("downloadButton");
        
        ToolBar toolBar = new ToolBar(
                newButton,
                editButton,
                deleteButton,
                downloadButton,
                helpButton
               
        );

     

        return toolBar;
	}
}
